package model;

public interface Actor {
    // Empty nothing specific
}
